import { Component, OnInit, ViewChild } from '@angular/core';
import { MatSelect } from '@angular/material/select';

@Component({
  selector: 'toolbar-multirow-example',
  templateUrl: 'toolbar-multirow-example.html',
  styleUrls: ['toolbar-multirow-example.css'],
})
export class ToolbarMultirowExample implements OnInit {
  allDoctors = Array.from(new Array(40000).keys()).map((i) => 'Doctor ' + i);
  viewDoctors = this.allDoctors.slice(0, 10);
  viewIndex = 0;
  windowSize = 10;
  private readonly PIXEL_TOLERANCE = 3.0;

  selected: any = 'Doctor 100';
  @ViewChild('doctorSelect') selectElem: MatSelect;

  ngOnInit() {
    this.selectElem.openedChange.subscribe((val) => {
      if (val) {
        console.log('registerred');
        this.registerPanelScrollEvent();
      }
    });
  }

  registerPanelScrollEvent() {
    const panel = this.selectElem.panel.nativeElement;
    panel.addEventListener('scroll', (event) => this.loadNextOnScroll(event));
  }

  loadNextOnScroll(event) {
    if (this.hasScrolledToBottom(event.target)) {
      console.log('Scrolled to bottom');
      this.viewIndex += this.windowSize;
      this.viewDoctors = this.allDoctors.slice(0, this.viewIndex);
    }
  }

  private hasScrolledToBottom(target): boolean {
    return (
      Math.abs(target.scrollHeight - target.scrollTop - target.clientHeight) <
      this.PIXEL_TOLERANCE
    );
  }

  reset() {
    // this.viewDoctors = this.allDoctors.slice(0, 10);
  }
}
